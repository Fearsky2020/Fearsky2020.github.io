# Source and attribution

This Agent Skill is redistributed by GOED WEBWERK from an open-source project.

- Original repository: https://github.com/alirezarezvani/claude-skills
- Source commit: 19392f7a08264ed00486a251f5b2098321771f94
- Original path: research/syllabus/skills/syllabus/SKILL.md
- Declared license: MIT
- Original source URL: https://github.com/alirezarezvani/claude-skills/blob/19392f7a08264ed00486a251f5b2098321771f94/research/syllabus/skills/syllabus/SKILL.md

GOED WEBWERK does not automatically execute bundled scripts. Review a Skill and its files before installing or running it.
