# Source and attribution

This Agent Skill is redistributed by GOED WEBWERK from an open-source project.

- Original repository: https://github.com/AgriciDaniel/claude-seo
- Source commit: ff87fcee0734845d3f59128c8c905799ee2298da
- Original path: skills/seo-page/SKILL.md
- Declared license: MIT
- Original source URL: https://github.com/AgriciDaniel/claude-seo/blob/ff87fcee0734845d3f59128c8c905799ee2298da/skills/seo-page/SKILL.md

GOED WEBWERK does not automatically execute bundled scripts. Review a Skill and its files before installing or running it.
